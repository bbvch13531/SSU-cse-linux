#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int main(int argc, char **argv){
	while(1){	// 계속 반복
		printf("\n[OSLAB]");
		sleep(5);
	}
	exit(0);
}
